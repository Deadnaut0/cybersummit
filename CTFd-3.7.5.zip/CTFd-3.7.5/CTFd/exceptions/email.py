class UserConfirmTokenInvalidException(Exception):
    pass


class UserResetPasswordTokenInvalidException(Exception):
    pass
