import{C as o,m as d}from"./index.2e31e3b8.js";window.CTFd=o;window.Alpine=d;d.start();
