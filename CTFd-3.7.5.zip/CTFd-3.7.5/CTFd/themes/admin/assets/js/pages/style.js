import $ from "jquery";
import styles from "../styles";
import times from "../compat/times";

$(() => {
  styles();
  times();
});
